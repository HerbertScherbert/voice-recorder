# CV_Leave a voice mail

A Pen created on CodePen.

Original URL: [https://codepen.io/Design-Develop-Develop/pen/gbMWvxW](https://codepen.io/Design-Develop-Develop/pen/gbMWvxW).

